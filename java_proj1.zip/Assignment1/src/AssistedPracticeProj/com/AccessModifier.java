package AssistedPracticeProj.com;

public class AccessModifier {

	public static void main(String[] args) {
		//Creating instance of test class
		Test t=new Test();
		
		//Accessing public members of test class
		t.publicMethod();//accessible
		System.out.println(t.publicVariable);
		
		//Accessing protected members of test class
		t.protectedMethod();//accessible
		System.out.println(t.protectedVariable);
		
		//Accessing default(package) members of test class
		t.defaultMethod();//accessible
		System.out.println(t.defaultVariable);
		
		//Accessing private members of test class
		//t.privatecMethod();//not accessible in other class
		//System.out.println(t.privateVariable);
	}

}

class Test{
	public int publicVariable=10;
	protected int protectedVariable=20;
	int defaultVariable=30;
	private int privateVariable=40;
	
	public void publicMethod()
	{
		System.out.println("This is a public method");
	}
	
	protected void protectedMethod()
	{
		System.out.println("This is a protected method");
	}
	
	void defaultMethod()
	{
		System.out.println("This is a package method");
	}
	
	private void privateMethod()
	{
		System.out.println("This is a private method");
	}
}
