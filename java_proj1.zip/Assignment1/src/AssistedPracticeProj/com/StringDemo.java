package AssistedPracticeProj.com;

public class StringDemo {

	public static void main(String a[]) 
	{
		//string buffer
		StringBuffer s1=new StringBuffer();
		StringBuffer s2 =new StringBuffer("Welcome");
		System.out.println("String Buffer");
		System.out.println(s2);
		System.out.println(s2.reverse());
		System.out.println(s1.capacity());
		System.out.println(s1.append("Hello"));
		System.out.println(s1.append(" Java is my fav language"));
		System.out.println(s1.capacity());
		
		//StringBuilder
		System.out.println("\n");
		System.out.println("StringBuilder");
		StringBuilder s3=new StringBuilder("Happy");
	    s3.append(" Morning");
		System.out.println(s3);
		System.out.println(s3.delete(0, 4));
		System.out.println(s3.insert(1, " Hello"));
		System.out.println(s3.reverse());

	
						
		//Conversion	
		System.out.println("\n");	
		String str = "Pavithra"; 
		        
		  // conversion from String to StringBuffer 
		  StringBuffer sb = new StringBuffer(str); 
		  sb.reverse(); 
		  System.out.println("String to StringBuffer");
		  System.out.println(sb); 
		          
		  // conversion from String to StringBuilder 
		  StringBuilder sbl = new StringBuilder(str); 
		  sbl.append(" R"); 
		  System.out.println("String to StringBuilder");
		  System.out.println(sbl);              	
	}
}
