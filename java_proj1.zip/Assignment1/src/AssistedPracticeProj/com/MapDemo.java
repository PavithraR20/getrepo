package AssistedPracticeProj.com;

import java.util.HashMap;

import java.util.Hashtable;

import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {

		//Creating Hashmap;
		Map<Integer,String> map=new HashMap();
		
		//Adding key and value
		map.put(101,"Pavithra");
		map.put(102, "Deepak");
		map.put(103,"Surya");
		System.out.println("The hashmap elements are:");
		for(Map.Entry<Integer,String> itr :map.entrySet())
		{
			int key=itr.getKey();
			String value=itr.getValue();
			System.out.println("Key : "+key+" Value : "+value);
		}
		
		//System.out.println(map.containsKey(103));
		//System.out.println(map.containsValue("Pavithra"));
		//System.out.println(map.get(102));
		
		//Creating HashTable
		
       Map<Integer,String> ht=new Hashtable<Integer, String>();
		
		//Adding key and value
		ht.put(105,"Vikas");
		ht.put(106, "Alia");

		System.out.println("The hashtable elements are:");
		for(Map.Entry<Integer,String> itr :ht.entrySet())
		{
			int key=itr.getKey();
			String value=itr.getValue();
			System.out.println("Key : "+key+" Value : "+value);
		}
	}

}
