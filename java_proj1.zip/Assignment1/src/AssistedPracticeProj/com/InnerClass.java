package AssistedPracticeProj.com;

class A
{
	int age;
	public void show()
	{
		System.out.println("class A method:Outer method");
	}
	class B
	{
		public void config()
		{
			System.out.println("class B method:Inner method");
		}
	}
}


public class InnerClass {
	
	public static void main(String[] args) {
		
		A a=new A();
		a.show();
		
		A.B b=a.new B();
		b.config();
	}
}
