package AssistedPracticeProj.com;

public class ArrayDemo {

	public static void main(String[] args) {
	
		//creating array of int type
		int[] a= {1,2,3,4,5};
		
		//accessing array element
		System.out.println("Array elements:");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		//modifying array element
		a[2]=10;
		
		//accessing array element after modifying
		System.out.println("Modified array elements:");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		//finding max element in array
		int max=a[0];
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>max) 
			{
				max=a[i];
			}
		}
		System.out.println("Max element: "+max);
		}
	}
