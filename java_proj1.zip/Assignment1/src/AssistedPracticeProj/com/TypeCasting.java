package AssistedPracticeProj.com;

public class TypeCasting {

	public static void main(String[] args) {
		
		//Implicit Type Casting
		System.out.println("Implicit Type Casting");
		int a=5;
		double d1=a;//implicit casting from int to double
		System.out.println("Implicit casting: from int to double");
		
		//Explicit Type Casting
		System.out.println("Explicit Type Casting");
		double d2=10.5;
		int a2=(int)d2;// explicit casting from double to int
		System.out.println("Explicit Casting: from double to int");	

	}

}
