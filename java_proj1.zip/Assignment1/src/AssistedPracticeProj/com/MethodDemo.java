package AssistedPracticeProj.com;

public class MethodDemo {

	public static void main(String[] args) {
		
		MethodDemo m=new MethodDemo();
		
		
	   //calling static method
		MethodDemo.staticMethod("Hello World!!");
		
		//calling instance method
		m.instanceMethod("Java:)");
		
		//method overloading:calling with different number
		int res1=add(5,6);
		int res2=add(5,6,7);
		System.out.println("Method Overloading with 2 arg "+res1);
		System.out.println("Method Overloading with 3 arg "+res2);
		
	}
	
	//Method Overloading:with 3 args
    public static int add(int i, int j, int k) {
		return i+j+k;
	}

    //Method Overloading:with 2 args
	public static int add(int i, int j) {
		
		return i+j;
	}

    //Instance Method
	public void instanceMethod(String string) {
    	System.out.println("This is instance method");
		System.out.println(string);
		
	}

	//Static method
	public static void staticMethod(String string) 
	{
		System.out.println("This is static method");
		System.out.println(string);
	}

}


