package AssistedPracticeProj.com;

public class ConstructorTypes {
	
	String name;
	String Country;
	int age;
	
	//default constructor
	public ConstructorTypes()
	{
		name="Pavithra";
		Country="India";
		age=22;
	}
	 
	
	//parameterised Constructor
	public ConstructorTypes(String name,String Country,int age)
	{
		this.name=name;
		this.Country=Country;
		this.age=age;
	}
	
	//Copy Constructor
	public ConstructorTypes(String name,String Country,ConstructorTypes c)
	{
		this.name=name;
		this.Country=Country;
		this.age=c.age;
	}
	
	public void display()
	{
		System.out.println("Name : "+name);
		System.out.println("Country : "+Country);
		System.out.println("Age : "+age);
	}

	public static void main(String[] args) {
		System.out.println("Default Constructor");
		ConstructorTypes c1=new ConstructorTypes();//calling default constructor
		c1.display();
		
		System.out.println("Paratermised Constructor");
		ConstructorTypes c2=new ConstructorTypes("Surya","US",16);//calling paratermised constructor
		c2.display();
		
		System.out.println("Copy Constructor");
		ConstructorTypes c3= new ConstructorTypes("Deepika","London",c2);
		c3.display();
		
	}

}
