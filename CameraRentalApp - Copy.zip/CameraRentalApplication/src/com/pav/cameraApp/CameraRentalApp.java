package com.pav.cameraApp;

import java.util.*;

class Camera
{
	int cameraId;
	String brand;
	String model;
	double price;
	String status;
	
	public Camera(int cameraId,String brand,String model,double price,String status)
	{
		this.cameraId = cameraId;
		this.brand = brand;
		this.model = model;
		this.price = price;
		this.status = status;
	}
	
	public int getCameraId()
	{
		return cameraId;
	}
	
	public String getBrand()
	{
		return  brand;
	}
	
	public String getModel()
	{
		return  model;
	}
	
	public double getPrice() 
	{
		return price;
	}
	
	public String getStatus()
	{
		return status;
	}
	
	public void setStatus(String status)
	{
		this.status=status;
	}
}

public class CameraRentalApp {
	
	public static List<Camera> cameraList = new ArrayList<>(); 
	static double walletAmount;

	public static void main(String[] args) 
	{
		loadData();
		displayWelcomeScreen();
		login();
	}

	//Welcome Screen Message
	public static void displayWelcomeScreen() {
		System.out.println("\n***************************************************\n");
        System.out.println("\tWELCOME TO CAMERA RENTAL APP \n");
        System.out.println("***************************************************");
	}
	
	//Login
	public static void login() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("PLEASE LOGIN TO CONTINUE");
		System.out.print("USERNAME: ");
		String username=scanner.nextLine();
		System.out.print("PASSWORD: ");
		String password=scanner.nextLine();
		
		//Validate username and password 
		if(!username.equals("admin") ||!password.equals("admin123"))
		{
			System.out.println("Invalid Credentials, Please enter correct credentials");
			return;
		}
		
		//main menu
		boolean exit = false;
		while(!exit)
		{
			System.out.println("\n1. MY CAMERA");
			System.out.println("2. RENT A CAMERA");
			System.out.println("3. VIEW ALL CAMERA");
			System.out.println("4. MY WALLET");
			System.out.println("5. EXIT");
			
			System.out.print("\nENTER YOUR CHOICE: ");
			int choice=scanner.nextInt();
			
			switch(choice)
			{
			case 1:
				myCameraMenu();
				break;
				
			case 2:
				rentCamera();
				break;
				
			case 3:
				ViewAllCamera();
				break;
				
			case 4:
				myWallet();
				break;
				
			case 5:
				System.out.println("THANK YOU FOR USING CAMERA RENTAL APP:)");
				exit=true;
				break;
				
			default:
				System.out.println("INVALID CHOICE.PLEASE ENTER VALID CHOICE");
				break;
			}
			
		}
	}

	public static void myCameraMenu() {
		
		Scanner scan=new Scanner(System.in);
		boolean backToMain=false;
		
		while(!backToMain)
		{
			System.out.println("\n1. ADD");
			System.out.println("2. REMOVE");
			System.out.println("3. VIEW MY CAMERA");
			System.out.println("4. GO TO PREVIOUS MENU");
			System.out.print("\nENTER YOUR CHOICE: ");
			int choice=scan.nextInt();
			
			switch(choice)
			{
			case 1:
				addCamera();
				break;
				
			case 2:
				removeCamera();
				break;
				
			case 3:
				viewMyCamera();
				break;
				
			case 4:
				backToMain=true;
				break;
				
			default:
				System.out.println("Invalid choice.Please try again");
				break;
			}
		}
	}
	
	//Adding camera to list
	public static void addCamera()
	{
		Scanner scan=new Scanner(System.in);
		
		System.out.print("ENTER THE CAMERA BRAND : ");
		String brand = scan.nextLine();
		
		System.out.print("ENTER THE CAMERA MODEL : ");
		String model = scan.nextLine();
		
		System.out.print("ENTER THE PER DAY PRICE : ");
		double price=scan.nextDouble();
		
		int cameraId=cameraList.size()+1;
		
		//set the initial status of the camera as available
		String status = "Available";
		
		Camera camera = new Camera(cameraId,brand,model,price,status);
		cameraList.add(camera);
		
		System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
	}
	
	//removing camera from list
	public static void removeCamera()
	{
		Scanner scanner=new Scanner(System.in);
		displayCameraList();
		
		System.out.print("ENTER THE CAMERA ID TO REMOVE: ");
		int cameraId=scanner.nextInt();
		
		boolean cameraRemoved = false;
		for (Camera camera : cameraList)
		{
			if(camera.getCameraId() == cameraId)
			{
				cameraList.remove(camera);
				cameraRemoved = true;
				break;
			}
		}
		if(cameraRemoved) System.out.println("CAMERA SUCCESSFULLY REMOVED FROM LIST.");
		else System.out.println("CAMERA NOT FOUND IN THE LIST");
	}
	
	//Camera list
	public static void viewMyCamera()
	{
		displayCameraList();
	}
	
	public static void loadData()
	{
		cameraList.add(new Camera(11,"Nikon","DSLR",500,"Rented"));
		cameraList.add(new Camera(12,"sony","SONY123",2500,"Available"));
		cameraList.add(new Camera(13,"canon","DSLR",1000,"Available"));
		cameraList.add(new Camera(15,"samsang","SM123",250,"Available"));
		cameraList.add(new Camera(17,"Pansonic","XC",550,"Available"));
		cameraList.add(new Camera(18,"LG","5025",600,"Available"));
		cameraList.add(new Camera(21,"Chroma","CT",800,"Available"));
	}
	
	public static void displayCameraList()
	{
		System.out.println("==============================================================================");
		System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE\t\tSTATUS");
		System.out.println("===============================================================================");
		for(Camera camera : cameraList)
		{
			System.out.printf("%-15s %-15s %-15s %-15s %-15s\n",camera.getCameraId(),camera.getBrand(),camera.getModel(),camera.getPrice(),camera.getStatus());
		}
		System.out.println("================================================================================");
	}
	
	//Rent a camera
	private static void rentCamera() {
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S)");
	    displayCameraList();
	    System.out.print("ENTER THE CAMERA ID YOU WANT TO RENT: ");
	    int cameraId = scanner.nextInt();

	    // Find the camera in the list
	    Camera selectedCamera = null;
	    for (Camera camera : cameraList) {
	        if (camera.getCameraId() == cameraId) {
	            selectedCamera = camera;
	            break;
	        }
	    }

	    if (selectedCamera == null || !selectedCamera.getStatus().equals("Available")) {
	        System.out.println("CAMERA NOT AVAILABLE FOR RENT.");
	        return;
	    }

	    if (selectedCamera.getPrice() > walletAmount) {
	        System.out.println("TRANSACTION FAILED DUE TO INSUFFICIENT WALLET BALANCE.PLEASE DEPOSIT THE AMOUNT TO YOUR WALLET");
	        return;
	    }

	    selectedCamera.setStatus("Rented");
	    walletAmount -= selectedCamera.getPrice();

	    System.out.println("YOUR TRANSACTION FOR CAMERA - " + selectedCamera.getBrand() + " " + selectedCamera.getModel() +
	            " WITH RENT OF INR." + selectedCamera.getPrice() + " HAS BEEN SUCCESSFULLY COMPLETED.");
	}

	
	//View all camera details
	public static void ViewAllCamera()
	{
		displayCameraList();
	}
	
	//Wallet menu
	public static void myWallet()
	{
		Scanner scanner = new Scanner(System.in);
	    System.out.println("YOUR CURRENT WALLET BALANCE IS: INR " + walletAmount);
	    
	    System.out.print("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET?(1.YES 2.NO) ");
	    int choice = scanner.nextInt();
	    
	    if (choice == 1) 
	     {
	        System.out.print("ENTER THE AMOUNT(INR): ");
	        double depositAmount = scanner.nextDouble();
	        walletAmount += depositAmount;
	        System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE - INR " + walletAmount);
	    }
	}
}



