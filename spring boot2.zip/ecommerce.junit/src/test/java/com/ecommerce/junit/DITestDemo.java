package com.ecommerce.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DITestDemo {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
