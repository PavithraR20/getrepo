package com.student;

public class ProductNotFoundException extends RuntimeException {

}