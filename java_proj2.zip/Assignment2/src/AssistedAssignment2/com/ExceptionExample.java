package AssistedAssignment2.com;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionExample {
    public static void main(String[] args) {
        try {
        	callMe1();
        } catch (CustomException e) {
            System.out.println("CustomException caught: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }
    
    public static void callMe1() throws CustomException {
        try {
        	callMe2();
        } catch (ArithmeticException e) {
            throw new CustomException("ArithmeticException occurred.");
        }
    }
    
    public static void callMe2() throws ArithmeticException {
        int res=10/0; // This line will throw an ArithmeticException
    }
}