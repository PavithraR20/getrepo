package AssistedAssignment2.com;

//Extending Thread Class
class Thread1 extends Thread
{
	@Override
	public void run()
	{
		System.out.println("Thread created by extending Thread class ");
	}
}

//Implementing Runnable interface
class Thread2 implements Runnable
{
	@Override
	public void run()
	{
		System.out.println("Thread created by implementing Runnable interface");
	}
}


public class ThreadExample {

	public static void main(String[] args) {
		//creating and starting the thread using Thread class
		Thread1 t1=new Thread1();
		t1.start();
		
		//Creating and starting the thread using Runnable interface
		Thread2 t2=new Thread2();
		Thread thread=new Thread(t2);
		thread.start();

	}

}
