package AssistedAssignment2.com;

public class SleepAndWaitDemo {

	public static void main(String[] args) {
		SleepThread t1=new SleepThread();
		Wait t2=new Wait();
		
		t1.start();
		t2.start();

	}
   static class SleepThread extends Thread
    {
    	@Override
    	public void run()
    	{
    		System.out.println("Sleep Demo:");
    		try
    		{
    			for(int i=1;i<=5;i++)
    			{
    				Thread.sleep(6000);
    				System.out.println(i);
    			}
    		}
    		catch(Exception e)
    		{
    			System.out.println(e);
    		}
    	}
		
    }
    static class Wait extends Thread
    {
    	@Override
    	public void run()
    	{
    		System.out.println("Wait Demo:");
    		synchronized(this)
    		{
    			try
        		{
        			for(int i=1;i<=5;i++)
        			{
        				Thread.sleep(1000);
        				System.out.println(i);
        			}
        		}
        		catch(Exception e)
        		{
        			System.out.println(e);
        		}
    			
    		}
    	}
    }
}
