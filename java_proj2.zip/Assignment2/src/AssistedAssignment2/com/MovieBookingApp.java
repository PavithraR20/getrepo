package AssistedAssignment2.com;

class BookTheatreSeat
{
	int total_seats=10;
	 void bookSeat(int seats)
	{
		
		synchronized(this)
		{
			if(total_seats>=seats)
			{
				System.out.println(seats+" seats booked successful");
				total_seats=total_seats-seats;
				System.out.println("Seats left: "+total_seats);
			}
			else
			{
				System.out.println("sorry seats cannot be booked..");
				System.out.println("Seats left: "+total_seats);
			}
		}
	}
}

public class MovieBookingApp extends Thread {
	static BookTheatreSeat b;
    int seats;
	public void run()
	{
		b.bookSeat(seats);
	}

	public static void main(String[] args) 
	{
		 b=new BookTheatreSeat();
		
		MovieBookingApp pavithra=new MovieBookingApp();
		pavithra.seats=7;
		pavithra.start();
		

		MovieBookingApp surya=new MovieBookingApp();
		surya.seats=6;
		surya.start();
	}

}
