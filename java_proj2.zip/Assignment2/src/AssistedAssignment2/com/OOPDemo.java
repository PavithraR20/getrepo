package AssistedAssignment2.com;

//Class definition for a Car
class Car {
 private String brand;
 private String color;
 
 // Constructor
 public Car(String brand, String color) {
     this.brand = brand;
     this.color = color;
 }
 
 // Getter methods
 public String getBrand() {
     return brand;
 }
 
 public String getColor() {
     return color;
 }
 
 // Method to start the car
 public void start() {
     System.out.println("The " + brand + " car has started.");
 }
}

//Class inheritance example
class SportsCar extends Car {
 private boolean turbo;
 
 // Constructor
 public SportsCar(String brand, String color, boolean turbo) {
     super(brand, color);
     this.turbo = turbo;
 }
 
 // Method overriding
 @Override
 public void start() {
     System.out.println("The " + getBrand() + " sports car with turbo has started.");
 }
 
 // Method specific to SportsCar class
 public void activateTurbo() {
     if (turbo) {
         System.out.println("Turbo activated!");
     } else {
         System.out.println("This sports car doesn't have a turbo.");
     }
 }
}

//Main class
public class OOPDemo {
 public static void main(String[] args) {
     // Creating objects of Car class
     Car car1 = new Car("Toyota", "Red");
     Car car2 = new Car("Honda", "Blue");
     
     // Accessing object properties
     System.out.println("Car 1: " + car1.getBrand() + " - " + car1.getColor());
     System.out.println("Car 2: " + car2.getBrand() + " - " + car2.getColor());
     
     // Calling object methods
     car1.start();
     car2.start();
     
     // Creating object of SportsCar class
     SportsCar sportsCar = new SportsCar("Ferrari", "Yellow", true);
     
     // Accessing inherited properties
     System.out.println("Sports Car: " + sportsCar.getBrand() + " - " + sportsCar.getColor());
     
     // Calling overridden method
     sportsCar.start();
     
     // Calling specific method of SportsCar class
     sportsCar.activateTurbo();
 }
}