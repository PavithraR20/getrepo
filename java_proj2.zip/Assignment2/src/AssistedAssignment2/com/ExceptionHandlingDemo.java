package AssistedAssignment2.com;

public class ExceptionHandlingDemo {

	public static void main(String[] args) {
		int [] a= {10,20,30,40,50};
		try
		{
			System.out.println(a[40]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Handled...");
		}
	}

}
