package AssistedAssignment2.com;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class FileDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the file path: ");
        String filePath = scanner.nextLine();

        File file = new File(filePath);

        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("File created successfully.");
                } else {
                    System.out.println("Failed to create the file.");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("File already exists.");
        }

        System.out.println("Enter the content to write to the file: ");
        String content = scanner.nextLine();

        try {
            Files.write(Paths.get(filePath), content.getBytes());
            System.out.println("Content written to the file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("File content:");
        try {
            String fileContent = new String(Files.readAllBytes(Paths.get(filePath)));
            System.out.println(fileContent);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Enter the new content to update the file: ");
        String newContent = scanner.nextLine();

        try {
            Files.write(Paths.get(filePath), newContent.getBytes());
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("File content after update:");
        try {
            String updatedContent = new String(Files.readAllBytes(Paths.get(filePath)));
            System.out.println(updatedContent);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}
