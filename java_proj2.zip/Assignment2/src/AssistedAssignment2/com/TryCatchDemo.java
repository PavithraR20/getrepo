package AssistedAssignment2.com;

public class TryCatchDemo {

	public static void main(String[] args) {
		System.out.println("main() starts");
		try
		{
			System.out.println(10/0);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Exception Handled");
		}
		System.out.println("main() ends");

	}

}
