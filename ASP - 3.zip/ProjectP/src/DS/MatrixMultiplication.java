package DS;

public class MatrixMultiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a= {5,8,12,7,6,24};
		int k=4;
		

		System.out.println("Original Array is: ");
		for(int i=0;i<a.length;i++)
			System.out.print("\t"+a[i]);	
		
		
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			if(i==k-1)
			{
				System.out.println("\n\n 4th smallest element in the array : "+a[i]);
			}
		}
	}

}
