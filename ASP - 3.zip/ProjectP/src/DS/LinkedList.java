package DS;

public class LinkedList {
	
	Node head;

    static class Node {
        int data;
        Node next;

        Node(int d) {
            data = d;
            next = null;
        }
    }

    void deleteKey(int key) {
        Node temp = head;
        Node prev = null;

        // Check if the head node itself holds the key to be deleted
        if (temp != null && temp.data == key) {
            head = temp.next;
            return;
        }

        // Search for the key to be deleted, keeping track of the previous node
        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        // If the key was not present in the linked list
        if (temp == null) {
            return;
        }

        // Unlink the node from the linked list
        prev.next = temp.next;
    }

    void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList linkedList = new LinkedList();
        linkedList.head = new Node(3);
        Node second = new Node(6);
        Node third = new Node(9);
        Node fourth = new Node(12);

        linkedList.head.next = second;
        second.next = third;
        third.next = fourth;

        System.out.println("Linked List before deletion:");
        linkedList.printList();

        int key = 6;
        linkedList.deleteKey(key);

        System.out.println("Linked List after deleting " + key + ":");
        linkedList.printList();

	}

}
