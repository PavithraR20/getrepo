package DS;

public class SortedCircularLinkedList {
	
	static class Node {
        int data;
        Node next;

        Node(int d) {
            data = d;
            next = null;
        }
    }

    Node head;

    // Function to insert a new node into a sorted circular linked list
    void insert(int newData) {
        Node newNode = new Node(newData);
        
        // If the list is empty, make the new node as the head and point it to itself
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (newData <= head.data) {
            // If the new data is smaller than or equal to the head's data, insert at the beginning
            Node last = getLastNode();
            last.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            // Find the node after which the new node should be inserted
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Function to get the last node of the circular linked list
    Node getLastNode() {
        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }
        return temp;
    }

    // Function to display the elements of the circular linked list
    void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
        System.out.println();
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  SortedCircularLinkedList list = new SortedCircularLinkedList();

	        // Inserting elements into the sorted circular linked list
	        list.insert(10);
	        list.insert(20);
	        list.insert(30);
	        list.insert(40);

	        System.out.println("Sorted Circular Linked List:");
	        list.display();

	}

}
