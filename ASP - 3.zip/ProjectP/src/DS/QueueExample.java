package DS;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {

		 public static void main(String[] args) {
		        Queue<Integer> queue = new LinkedList<>();

		        // Inserting elements into the queue
		        queue.offer(10);
		        queue.offer(20);
		        queue.offer(30);
		        queue.offer(40);

		        System.out.println("Queue after inserting elements: " + queue);

		        // Removing elements from the queue
		        int removedElement = queue.poll();
		        System.out.println("Removed element: " + removedElement);
		        System.out.println("Queue after removing an element: " + queue);

		        // Accessing the head of the queue without removing it
		        int headElement = queue.peek();
		        System.out.println("Head of the queue: " + headElement);
		        System.out.println("Queue after peeking: " + queue);

	}

}
