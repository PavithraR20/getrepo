package com.pav;

public class ExponentialSearch {

	public static void main(String[] args) {
		int[] inputArray= {20,30,40,45,50,61,77,91,95,97};
		int searchElement=97;
		
		int result=exponentialSearch(inputArray,inputArray.length-1,searchElement);
		
		if(result == -1)
		{
			System.out.println("Search Element "+ searchElement+" not found in the given Input Array");
		}
		else
		{
			System.out.println("Element is found at the index "+result+" index position");
		}

	}

	public static int exponentialSearch(int[] inputArray, int size, int searchElement) {
		if(size==0)
		{
			return -1;  
		}
		
		int bound=1;
		while(bound< size && inputArray[bound] < searchElement)
		{
			bound*=2;
		}
		return binarySearch(inputArray,bound/2,Math.min(bound+1, size),searchElement);
	}

	public static int binarySearch(int[] array, int firstIndex, int lastIndex, int searchElement) {
		
		while(firstIndex <= lastIndex)
		{
			int middlePosition = (firstIndex + lastIndex)/2;
			
			if(array[middlePosition] == searchElement)
			{
				return middlePosition;
			}
			else if(array[middlePosition] > searchElement)
			{
				return binarySearch(array,firstIndex,middlePosition - 1,searchElement);
			}
			else
			{
				return binarySearch(array,middlePosition + 1,lastIndex,searchElement);
			}
		}
		return -1;
	}

}
