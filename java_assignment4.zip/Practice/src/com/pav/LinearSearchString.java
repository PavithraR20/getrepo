package com.pav;

public class LinearSearchString {

	public static void main(String[] args) {
		
		String[] city= {"Bangalore","Dehli","Mumbai","Hyderabad","Pune"};
		
		String item="Bangalore";
		int temp=0;
		for(int i=0;i<city.length;i++)
		{
			if(city[i].equals(item)) {
				System.out.println(item+" is Present at "+i+" Index Position");
				temp=temp+1;
			}
		}
		if(temp==0)
		{
			System.out.println("City not found in the list");
		}
	}

}
