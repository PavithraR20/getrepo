package com.pav;

public class SelectionSortString {

	public static void main(String[] args) {
		
		String[] city= {"Bangalore","Dehli","Mumbai","Hyderabad","Pune"};
		
		int min;
		String temp="";
		
		for(int i=0;i<city.length;i++)
		{
			min=i;
			for(int j=i+1;j<city.length;j++)
			{
				if(city[j].compareTo(city[min])<0)
				{
					min=j;
				}
			}
			temp=city[i];
			city[i]=city[min];
			city[min]=temp;
		}
		System.out.println("Sorted City List: ");
		for(int i=0;i<city.length;i++)
		{
			System.out.print(city[i]+" ");
		}

	}

}
